#!/usr/bin/env Rscript
#-------------------------------------------------------------------------
### Author: Huaying Fang hyfang@stanford.edu
##############################################
# 1. Packages required
require(data.table); # version: 1.11.8
require(e1071); # version: 1.7-0.1
#---------------------------------------
# 2-steps cross validation for SVM in hare assignment
cv2steps_hare <- function(fml_svm, dat, n_cv = 5, para_best = c(-2, 0), step_cv0 = c(3, 3), step_cv1st = c(2, 2), step_cv2nd = c(1, 1)) {
	step_mat <- cbind(step_cv0, step_cv1st, step_cv2nd);
	if(sum(abs(step_cv0 - step_cv1st)) < 1e-6) {
        step_mat <- step_mat[, -1];
    }
	perf_best <- 0;
    mark_para <- NULL;
	for(k0 in 2:ncol(step_mat)) {
		a0 <- para_best - step_mat[, k0 - 1];
        b0 <- para_best + step_mat[, k0 - 1];
		gamma0 <- seq(a0[1], b0[1], by = step_mat[1, k0]);
        cost0 <- seq(a0[2], b0[2], by = step_mat[2, k0]);
		para0 <- cbind(gamma = gamma0, cost = rep(cost0, each = length(gamma0)));
		mark0 <- paste0(para0[, 1], "_", para0[, 2]);
		para0 <- para0[!mark0 %in% mark_para, ];
        mark_para <- mark0;
		perf_cv <- sapply(1:nrow(para0), function(k1) {
			return(sum(sapply(1:n_cv, function(k2) {
				mod_svm <- svm(formula = fml_svm, data = dat[dat$id_cv != k2, ], kernel = "radial", gamma = 10^para0[k1, 1], cost = 10^para0[k1, 2], fitted = F);
				pred_svm <- predict(mod_svm, newdata = dat[dat$id_cv == k2, ]);
				return(sum(pred_svm == dat$SIRE[dat$id_cv == k2]));
			})));
		});
		if(max(perf_cv) > perf_best) {
            para_best <- unlist(para0[which.max(perf_cv), ]);
        }
	}
    
	return(para_best);
}
#---------------------------------------
# Hare assignment
assign_hare <- function(dat, thr_has_sire = 40, thr_no_sire = 20, n_pcs = 30, n_cv = 5, para_best = c(-2, 0), step_cv0 = c(3, 3), step_cv1st = c(2, 2), step_cv2nd = c(1, 1), n_round = 2, seed_cv = 20190205) {
    set.seed(seed_cv);
	dat$SIRE <- as.factor(dat$SIRE);
	has_sire <- !is.na(dat$SIRE);
	dat$id_cv <- 0;
    dat$id_cv[has_sire] <- sample(1:n_cv, sum(has_sire), replace = T);
	fml_svm <- as.formula(paste0("SIRE~", paste0("PC", 1:n_pcs, collapse = "+")));
	# SVM training
	for(k0 in 1:n_round) { ## here we use two rounds
		idtmp0 <- dat$id_cv != 0;
		# 2-steps cross validation
		para_best <- cv2steps_hare(fml_svm = fml_svm, dat = dat[idtmp0, ], n_cv = n_cv, para_best = para_best, step_cv0 = step_cv0, step_cv1st = step_cv1st, step_cv2nd = step_cv2nd);
		# Probability SVM fitted
		mod_svm <- svm(formula = fml_svm, data = dat[idtmp0, ], kernel = "radial", gamma = 10^para_best[1], cost = 10^para_best[2], probability = T, fitted = T);
		pred_svm <- predict(mod_svm, newdata = dat[, paste0("PC", 1:n_pcs), with = F], probability = T);
		suspi_sire <- idtmp0 & pred_svm != dat$SIRE;
		# Information for best parameters and number of suspicious individuals
		cat("Best parameters for (gamma, cost) in Round ", k0, " (log10 scale): (", para_best[1], ", ", para_best[2], ").\n", sep = "");
		cat("Suspicious individuals in Round ", k0, ": ", sum(suspi_sire), ".\n", sep = "");
		# Remove suspicious individuals with SIRE and run cross validation again
		if(sum(suspi_sire) == 0) {
            break;
        } else {		
			dat$id_cv[suspi_sire] <- 0;
            dat$id_cv[dat$id_cv != 0] <- sample(1:n_cv, sum(dat$id_cv != 0), replace = T);
			step_cv0 <- step_cv1st;
		}
	}
	# HARE assigned
	dat_hare <- data.table(IID = dat$IID, SIRE = as.character(dat$SIRE), HARE = NA);
	prob_pred <- attr(pred_svm, "probabilities");
	P1P2Psire <- data.table(t(sapply(1:nrow(prob_pred), function(k) {
		x1 <- sort(prob_pred[k, ], decreasing = T);
		P1Psire <- ifelse(has_sire[k], x1[1]/max(x1[dat_hare$SIRE[k]], 1e-6), NA);
		return(c(x1[1]/max(x1[2], 1e-6), P1Psire, names(x1)[1]));
	})));
	names(P1P2Psire) <- c("P1P2", "P1Psire", "L1");
	for(k in 1:2) P1P2Psire[[k]] <- as.numeric(P1P2Psire[[k]]);
	# HARE = SIRE for individuals with sire and P1/Psire <= thr_has_sire
	idtmp0 <- has_sire & P1P2Psire$P1Psire <= thr_has_sire;
	dat_hare$HARE[idtmp0] <- dat_hare$SIRE[idtmp0];
	# HARE = L1 for individuals without sire and P1/P2 > thr_no_sire
	idtmp0 <- !has_sire & P1P2Psire$P1P2 > thr_no_sire;
	dat_hare$HARE[idtmp0] <- P1P2Psire$L1[idtmp0];

	return(dat_hare);
}
#-------------------------------------------------------------------------------
# Parameters required: file names for pcs, sire and hare.
args_cmd <- commandArgs(TRUE);
if(length(args_cmd) == 3) {
    file_pcs <- args_cmd[1]; # file name for pcs
    file_sire <- args_cmd[2]; # file name for sire
    file_hare <- args_cmd[3]; # file name for hare
} else {
    file_pcs <- "pop1_30pcs.txt";
    file_sire <- "pop1_sire.txt";
    file_hare <- "pop1_hare.txt";
}
#---------------------------------------
# Parameters default in hare assignment
thr_has_sire <- 40; # P1/Psire threshould for individuals with SIRE
thr_no_sire <- 20; # P1/P2 threshold for individuals without SIRE
n_pcs <- 30; # Number of PCs in SVM
n_cv <- 5; # Number of folds in Cross Validation
n_round <- 2; # Round times for re-run SVM 
para_best <- c(-2, -2); # Start points for (gamma, cost) in SVM
step_cv0 <- c(5, 4); # Region near start points: para_best -/+ step_cv0
step_cv1st <- c(2.5, 2); # Step in 1st of 2-steps Cross Validation
step_cv2nd <- c(1, 1); # Step in 2nd of 2-steps Cross Validation
#---------------------------------------
# Data prepared
dat_pcs <- fread(file_pcs, head = T, sep = "\t");
dat_sire <- fread(file_sire, head = T, sep = "\t");
dat <- merge(dat_pcs, dat_sire, by = "IID", all.x = T, sort = F);
rm(dat_pcs); rm(dat_sire);
#---------------------------------------
# HARE run
dat_hare <- assign_hare(dat = dat, thr_has_sire = thr_has_sire, thr_no_sire = thr_no_sire, n_pcs = n_pcs, n_cv = n_cv, para_best = para_best, step_cv0 = step_cv0, step_cv1st = step_cv1st, step_cv2nd = step_cv2nd, n_round = n_round);
fwrite(dat_hare, file = file_hare, sep = "\t", quote = F, na = "NA");
#-------------------------------------------------------------------------------
