This is a brief introduction accompanying HARE_run.R, which generates HARE variables using genetically inferred ancestry (GIA) and self-identified race/ethnicity (SIRE). This directory contains four files:
--README.txt (this file)
--HARE_run.R: The main R script for computing HARE
--pop1_30pcs.txt, pop1_sire.txt: input files of a toy data. 
--pop1_hare.txt: the output file

This version is a demo version that has been tested on computing environment that is MacOS v10.14 with 1.6 GHz Intel Core i5 (CPU) and 8GB RAM. The source code is a R script "HARE_run.R;" it requires R (version 3.5.1), and R packages data.table (version: 1.11.8) and e1071 (version: 1.7-0.1). A version implemented on linux accommodates larger dataset using an embarrassingly parallel scheme. 


The following are the steps for inferring HARE from GIA and SIRE. 

1. Prepare GIA file (see example "pop1_30pcs.txt"). This file contains genetic principle components (PCs). It has a column header, which should contain at least "IID", "PC1", ..., "PC30". All other columns will be ignored. The example file is the output of  flashPCA 2.0. The first two lines are:
FID	IID	PC1	PC2	PC3	PC4	PC5	PC6	PC7	PC8	PC9	PC10	PC11	PC12	PC13	PC14	PC15	PC16	PC17	PC18	PC19	PC20PC21	PC22	PC23	PC24	PC25	PC26	PC27	PC28	PC29	PC30
HG00096	HG00096	-0.07648856	-0.198386	0.05735373	0.03562765	-4.588342e-05	-0.005641554	0.007210726	0.01036338	-0.01387382	-0.008175781	0.0009384772	-0.01706808	-0.01097673	0.04488415	0.02825579	0.04409724	0.01294506	0.01896328	-0.0186372	0.007309824	-0.01274683	-0.01156632	-0.009898275	0.003503542	0.006119276	-0.02198939	-0.01136383	-0.002166306	-0.002081929	0.00500091


2. Prepare SIRE file (see example: "pop1_sire.txt"). This file contains SIRE; individuals without SIRE should be denoted as NA. This file has at least two columns: "IID" and "SIRE," all other columns will be ignored. The first two lines of the example file are:
IID	SIRE
HG00096	EUR


3. Run "HARE_run.R" through the following command :
	Rscript HARE_run.R <file_pcs> <file_sire> <output_fn>;
(substitute <file_pcs>, <file_sire>, and <output_fn> with the names for GIA file, SIRE file and output file, respectively).  

The example command to run "HARE_run.R" for example files "pop1_30pcs.txt" and "pop1_sire.txt" is
    Rscript HARE_run.R pop1_30pcs.txt pop1_sire.txt pop1_hare.txt;


**3(b) Alternatively, one can run "HARE_run.R" interactively in R console using:
	> source("HARE_run.R")

The default file names for PCs, SIRE and "HARE" are "pop1_30pcs.txt", "pop1_sire.txt" and "pop1_hare.txt," respectively; these file names can be modified by users on Line 95-97 in "HARE_run.R".  


4. The output file of running HARE_run.R is a file that includes 3 columns "IID", "SIRE" and "HARE" (see example: pop1_hare.txt").

The first 2 lines in the output file are,
IID	SIRE	HARE
HG00096	EUR	EUR

##About the toy example: These individuals are sampled from the 1000 Genome Project. Although all the individuals have SIRE, we randomly masked ~10% (n=101) of the individuals for demo purpose. Of these individuals, 100 are (correctly) assigned to the HARE group that corresponds to SIRE, and one remains unassigned. Of individuals with SIRE, HARE are the same as SIRE for all except one individual. This individual is from ASW (Americans of African Ancestry in SW USA), but PC indicates little African ancestry and substantial Native American ancestry. Therefore the HARE of this individual is assigned to missing. 